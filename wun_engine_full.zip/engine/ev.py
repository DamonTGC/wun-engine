def calculate_ev(prob, prop):
    odds=-110
    return round((prob*100)-100,2)