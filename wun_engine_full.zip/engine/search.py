def search_props(q):
    return {"results":[]}