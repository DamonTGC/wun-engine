import random

def simulate_prop(p):
    return random.uniform(0.4,0.7)  # cover probability placeholder